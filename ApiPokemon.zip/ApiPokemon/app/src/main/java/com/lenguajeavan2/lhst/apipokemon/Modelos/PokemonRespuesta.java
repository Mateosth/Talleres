package com.lenguajeavan2.lhst.apipokemon.Modelos;

import java.util.ArrayList;

/**
 * Created by usuario on 12/10/2017.
 */

public class PokemonRespuesta {
//Se captura lo del gjason el array
private ArrayList<Pokemon> results;
    public ArrayList<Pokemon> getResults() {
        return results;
    }

    public void setResults(ArrayList<Pokemon> results) {
        this.results = results;
    }

}
