package com.lenguajeavan2.lhst.apipokemon;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.lenguajeavan2.lhst.apipokemon.Modelos.Pokemon;
import com.lenguajeavan2.lhst.apipokemon.Modelos.PokemonRespuesta;
import com.lenguajeavan2.lhst.apipokemon.PagPokemonApi.PokemonApiServicio;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private Retrofit retrofit;//Creando instancia del retrofit
    private static final String TAG = "POKEMONES";//Tag a utilizar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        retrofit = new Retrofit.Builder()//Acceso desde la clase
                .baseUrl("http://pokeapi.co/api/v2/")//Url base
                .addConverterFactory(GsonConverterFactory.create())//Formateo de respuestas
                .build();
        obtenerDatos();//Método para obtener los datos

    }

    private void obtenerDatos() {
        PokemonApiServicio service = retrofit.create(PokemonApiServicio.class);//Obtener datos de la interfaz
        Call<PokemonRespuesta> pokemonRespuestaCall = service.obtenerListaPokemon();
        pokemonRespuestaCall.enqueue(new Callback<PokemonRespuesta>() {//Manejar los resultados en sus procesos internos
            @Override
            public void onResponse(Call<PokemonRespuesta> call, Response<PokemonRespuesta> response) {//Cuando llega la respuesta
                if (response.isSuccessful()) {//Si existe una respuesta

                    PokemonRespuesta pokemonRespuesta = response.body();
                    //Verificación por consola
                    ArrayList<Pokemon> listaPokemon=pokemonRespuesta.getResults();
                    for(int i=0; i<listaPokemon.size();i++){
                        Pokemon p=listaPokemon.get(i);
                        Log.i(TAG,"Pokemon:"+p.getName());
                    }
//Fin verificación por consola

                } else {//Sino existe respuesta
                    Log.e(TAG, " onResponse: " + response.errorBody());
                }



        }
            @Override
            public void onFailure(Call<PokemonRespuesta> call, Throwable t) {//Cuando hay algún error
                Log.e(TAG, " onFailure: " + t.getMessage());//Muestra si existe algún error

            }
        });
    }

    }

