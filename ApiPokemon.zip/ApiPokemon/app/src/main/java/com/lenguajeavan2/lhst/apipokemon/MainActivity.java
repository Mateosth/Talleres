package com.lenguajeavan2.lhst.apipokemon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.lenguajeavan2.lhst.apipokemon.Modelos.Pokemon;
import com.lenguajeavan2.lhst.apipokemon.Modelos.PokemonRespuesta;
import com.lenguajeavan2.lhst.apipokemon.PagPokemonApi.ActividadDetalle;
import com.lenguajeavan2.lhst.apipokemon.PagPokemonApi.ListaPokemonAdapter;
import com.lenguajeavan2.lhst.apipokemon.PagPokemonApi.PokemonApiServicio;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.R.attr.offset;

public class MainActivity extends AppCompatActivity {
    private Retrofit retrofit;//Creando instancia del retrofit

    private RecyclerView recyclerView;//Se instancia y se define
    public ListaPokemonAdapter listaPokemonAdapter;
    private static final String TAG = "POKEMONES";//Tag a utilizar
    private int offset;
    private boolean aptoParaCargar;
//-----------------------------------------------------------
    Toolbar mToolbar;
    ListView mListView;

//-----------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//Mostrar los items en forma de grilla
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        listaPokemonAdapter = new ListaPokemonAdapter(this);
        recyclerView.setAdapter(listaPokemonAdapter);
        recyclerView.setHasFixedSize(true);
        final GridLayoutManager layoutManager = new GridLayoutManager(this, 2);//Grilla en 2 columnas
        recyclerView.setLayoutManager(layoutManager);//Asignacion al recyclerView

        //Detectar o escuhar un movimiento de scroll
        //Detectando si el sroll es asi abjao y llegó al final
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (dy > 0) {
                    int visibleItemCount = layoutManager.getChildCount();
                    int totalItemCount = layoutManager.getItemCount();
                    int pastVisibleItems = layoutManager.findFirstVisibleItemPosition();

                    if (aptoParaCargar) {
                        if ((visibleItemCount + pastVisibleItems) >= totalItemCount) {
                            Log.i(TAG, " Llegamos al final.");

                            aptoParaCargar = false;
                            offset += 20;
                            obtenerDatos(offset);
                        }
                    }
                }
            }
        });




        retrofit = new Retrofit.Builder()//Acceso desde la clase
                .baseUrl("http://pokeapi.co/api/v2/")//Url base


                .addConverterFactory(GsonConverterFactory.create())//Formateo de respuestas
                .build();
        aptoParaCargar = true;
        offset = 0;
        obtenerDatos(offset);//Método para obtener los datos

    }

    public void obtenerDatos(int offset) {
        PokemonApiServicio service = retrofit.create(PokemonApiServicio.class);//Obtener datos de la interfaz
        Call<PokemonRespuesta> pokemonRespuestaCall = service.obtenerListaPokemon(20, offset);//Va de 20 en 20 mostrando
        pokemonRespuestaCall.enqueue(new Callback<PokemonRespuesta>() {//Manejar los resultados en sus procesos internos
            @Override
            public void onResponse(Call<PokemonRespuesta> call, Response<PokemonRespuesta> response) {//Cuando llega la respuesta
                aptoParaCargar = true;
                if (response.isSuccessful()) {//Si existe una respuesta

                    PokemonRespuesta pokemonRespuesta = response.body();
                    //Verificación por consola
                    ArrayList<Pokemon> listaPokemon=pokemonRespuesta.getResults();
                    //Se envía los datos al adaptador para mostrarlo graficamente

                    listaPokemonAdapter.adicionarListaPokemon(listaPokemon);
                    for(int i=0; i<listaPokemon.size();i++){
                        final Pokemon p=listaPokemon.get(i);
                        Log.i(TAG,"Pokemon:"+p.getName()+" "+ p.getNumber());
                       // Log.i(TAG,"Pokemon #:"+p.getNumber());
                       // Log.i(TAG,"Pokemon #:"+p.getUrl());


                    }
//Fin verificación por consola


                } else {//Sino existe respuesta
                    Log.e(TAG, " onResponse: " + response.errorBody());
                }
               // MyAdapter myAdapter = new MyAdapter(MainActivity.this,listaPokemonAdapter);
               // mListView.setAdapter(listaPokemonAdapter);
                //mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                   // @Override
                 //   public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                   //     Intent mIntent = new Intent(MainActivity.this,ActividadDetalle.class);
                     //   mIntent.putExtra("Nombre", p.getName());
                       // mIntent.putExtra("Número", p.getNumber());
                        //startActivity(mIntent);
                    //}
                //});

        }
            @Override
            public void onFailure(Call<PokemonRespuesta> call, Throwable t) {//Cuando hay algún error
                aptoParaCargar = true;
                Log.e(TAG, " onFailure: " + t.getMessage());//Muestra si existe algún error

            }
        });
    }

    }

