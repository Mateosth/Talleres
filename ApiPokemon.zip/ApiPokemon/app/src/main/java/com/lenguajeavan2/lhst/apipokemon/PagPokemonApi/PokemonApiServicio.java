package com.lenguajeavan2.lhst.apipokemon.PagPokemonApi;

import com.lenguajeavan2.lhst.apipokemon.Modelos.PokemonRespuesta;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by usuario on 12/10/2017.
 */

public interface PokemonApiServicio {
    @GET("pokemon")//Lograr número,nombre y url de pokemon
   //Si se deja sin parámetros solo muestra los 20 primeros pokemones
    //Con parámetros los muestra de 20 en 20 en forma consecutiva

    Call<PokemonRespuesta> obtenerListaPokemon(@Query("limit") int limit, @Query("offset") int offset);
}
