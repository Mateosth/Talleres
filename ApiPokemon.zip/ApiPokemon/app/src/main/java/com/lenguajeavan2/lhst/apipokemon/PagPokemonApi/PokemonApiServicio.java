package com.lenguajeavan2.lhst.apipokemon.PagPokemonApi;

import com.lenguajeavan2.lhst.apipokemon.Modelos.PokemonRespuesta;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by usuario on 12/10/2017.
 */

public interface PokemonApiServicio {
    @GET("pokemon")//Lograr número,nombre y url de pokemon
    Call<PokemonRespuesta> obtenerListaPokemon();
}
