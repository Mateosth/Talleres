package com.lenguajeavan2.lhst.parcial2_loguin_registro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

//    ArrayList<String> al = new ArrayList<String>();
    ArrayList persona=new ArrayList<>();
    ArrayList clavepersona=new ArrayList<>();
    //ArrayList<String> usuarios;
     Button boton,botoningresar,botonrecuperar;
    EditText txtusuario1;
    EditText txtclave1;
   // TextView claver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button boton=(Button) findViewById(R.id.btnboton);
        Button botonregistrar=(Button) findViewById(R.id.btningresar);
        Button botonrecuperar=(Button) findViewById(R.id.btnrecuperar);
       // TextView claver=(TextView)  findViewById(R.id.claver);


        boton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String usuario=((EditText) findViewById(R.id.txtusuario)).getText().toString();//Capturo el valor de txtusuario y lo convierto a string
                String clave=((EditText) findViewById(R.id.txtclave)).getText().toString();//Capturo el valor de txtclave y lo convierto a string

                if(usuario.equals("")||clave.equals("")){
                    Toast.makeText(getApplicationContext(),"Por Favor  NO DEJE CAMPOS VACÍOS",Toast.LENGTH_SHORT).show();

                }

                    else{
                            if(persona.contains(usuario)){//Busca si el valor está en la lista


                                Toast.makeText(getApplicationContext(),"EL USUARIO YA ESTÁ EN EL INSERTADO",Toast.LENGTH_SHORT).show();

                        }






else{
          persona.add(usuario);//Adicion a la lista
           clavepersona.add(clave);//Adicion a la lista clave
             Toast.makeText(getApplicationContext(),"EL USUARIO  : "+" "+usuario+" " +" FUE INSERTADO CON ÉXITO "+"\n" ,Toast.LENGTH_SHORT).show();


    }
}

                    }




            }
        );

    }
    public void Borrar(View view) {
        txtusuario1=((EditText) findViewById(R.id.txtusuario));//Capturo el valor de txtusuario y lo convierto a string
        txtclave1=((EditText) findViewById(R.id.txtclave));//Capturo el valor de txtclave y lo convierto a string
        txtusuario1.setText("");
        txtclave1.setText("");

    }
    public void Volver(View view) {
        Intent MiIntent=new Intent(MainActivity.this,Ventana2.class);
        startActivity(MiIntent);

    }
    public void Comprobar(View view){
        Intent explicit_intent;
        switch(view.getId()){
            case R.id.btningresar:

                 String usuario=((EditText) findViewById(R.id.txtusuario)).getText().toString();//Capturo el valor de txtusuario y lo convierto a string
                   String clave=((EditText) findViewById(R.id.txtclave)).getText().toString();//Capturo el valor de txtclave y lo convierto a string

                     if(usuario.equals("")||clave.equals("")){
                       Toast.makeText(getApplicationContext(),"Por Favor  NO DEJE CAMPOS VACÍOS",Toast.LENGTH_SHORT).show();

                        }

                        else{
                              if(persona.contains(usuario)&& clavepersona.contains(clave) ){//Busca si el valor está en la lista

                                explicit_intent = new Intent(MainActivity.this, Ventana2.class);
                                 explicit_intent.putExtra("Usuario",usuario);//Guardamos una cadena con los datos del usuario para la segunda ventana
                                  startActivity(explicit_intent );


                    }


                            else{

                                 Toast.makeText(getApplicationContext(),"DATOS ERRADOS.........",Toast.LENGTH_SHORT).show();


                    }



                break; }




            case R.id.btnrecuperar:

                              String usuario1=((EditText) findViewById(R.id.txtusuario)).getText().toString();//Capturo el valor de txtusuario y lo convierto a string
                                String clave1=((EditText) findViewById(R.id.txtclave)).getText().toString();//Capturo el valor de txtclave y lo convierto a string

                                   if(usuario1.equals("")||clave1.equals("")){
                                      Toast.makeText(getApplicationContext(),"Por Favor  NO DEJE CAMPOS VACÍOS",Toast.LENGTH_SHORT).show();

                                     }

                               else{
                                      if(persona.contains(usuario1) ){//Busca si el valor está en la lista
                                        int y=0;//Buscando la posición del usuario en el array

                                            y = persona.indexOf(usuario1);

                                               String claveDevuelta1 = "" + y;



                                                    String claveDevuelta="";
                                          //Con la posición buscar la clave
                                                         for(int z=0;z<clavepersona.size();z++){
                                                             if(z ==y){
                                                                 claveDevuelta= (String) clavepersona.get(z);
                                                              }
                                                         }


                                Toast.makeText(getApplicationContext(),"La clave del usuario "+" "+usuario1+"\n"+" "+ "es"+" "+claveDevuelta,Toast.LENGTH_SHORT).show();

                            }


                            else{

                                Toast.makeText(getApplicationContext(),"NO SE ENCUENTRA EL USUARIO .........",Toast.LENGTH_SHORT).show();

                            }
                             }
                break;
        }
    }
}