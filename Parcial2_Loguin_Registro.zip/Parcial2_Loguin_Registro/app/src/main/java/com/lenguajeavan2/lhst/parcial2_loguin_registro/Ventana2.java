package com.lenguajeavan2.lhst.parcial2_loguin_registro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Ventana2 extends AppCompatActivity {
    TextView etiNombreUsuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana2);

        setTitle("Entrada Al Sistema");
        etiNombreUsuario = (TextView) findViewById( R.id.eti_nombreUsuario );
        Intent intent=getIntent();
        Bundle extras =intent.getExtras();
        if (extras != null) {//ver si contiene datos
            String datoNombre=(String)extras.get("Usuario");//Obtengo el nombre del Planeta
            etiNombreUsuario.setText(datoNombre);//Capturo l nombre en un textView

        }



    }
    public void Volver(View view) {
        Intent MiIntent=new Intent(Ventana2.this,MainActivity.class);
        startActivity(MiIntent);

    }
}
